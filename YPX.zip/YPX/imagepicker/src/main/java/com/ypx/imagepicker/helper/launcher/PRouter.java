package com.ypx.imagepicker.helper.launcher;

import android.app.Fragment;
import android.content.Intent;
import android.util.SparseArray;

// silme
/**
 * 把OnActivityResult方式转换为Callback方式的空Fragment（标准SDK）
 *
 * Created by XiaoFeng on 2018/9/5.
 */
public class PRouter extends Fragment {

    private SparseArray<PLauncher.Callback> mCallbacks = new SparseArray<>();

    // silme
    public static PRouter newInstance() {
        return new PRouter();
    }

    // silme
    public void startActivityForResult(Intent intent, PLauncher.Callback callback) {
        mCallbacks.put(0, callback);
        startActivityForResult(intent,0 );
    }

    // silme
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        PLauncher.Callback callback = mCallbacks.get(requestCode);
        callback.onActivityResult(resultCode, data);
    }
}
