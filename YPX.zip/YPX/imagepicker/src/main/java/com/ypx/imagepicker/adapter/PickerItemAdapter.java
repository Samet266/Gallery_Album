package com.ypx.imagepicker.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.bean.selectconfig.BaseSelectConfig;
import com.ypx.imagepicker.bean.PickerItemDisableCode;
import com.ypx.imagepicker.views.PickerUiConfig;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.views.base.PickerItemView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

// silme
/** Description: 多选adapter <p>
 * Author: yangpeixing on 2018/4/6 10:32
 * Date: 2019/2/21 */
public class PickerItemAdapter extends RecyclerView.Adapter<PickerItemAdapter.ItemViewHolder> {
    private static final int ITEM_TYPE_CAMERA = 0;
    private static final int ITEM_TYPE_NORMAL = 1;
    private List<ImageItem> images;
    //选中图片列表
    private ArrayList<ImageItem> selectList;
    private BaseSelectConfig selectConfig;
    private IPickerPresenter presenter;
    private PickerUiConfig uiConfig;

    public PickerItemAdapter(ArrayList<ImageItem> selectList,
                             List<ImageItem> images,
                             BaseSelectConfig selectConfig,
                             IPickerPresenter presenter,
                             PickerUiConfig uiConfig) {
        this.images = images;
        this.selectList = selectList;
        this.selectConfig = selectConfig;
        this.presenter = presenter;
        this.uiConfig = uiConfig;
    }

    // silme
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ItemViewHolder(LayoutInflater.from(parent.getContext()).
                inflate(R.layout.picker_item_root, parent, false),
                viewType == ITEM_TYPE_CAMERA,
                selectConfig, presenter, uiConfig);
    }

    // silme
    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder viewHolder, @SuppressLint("RecyclerView") final int position) {
        final ImageItem imageItem = getItem(position);
        PickerItemView pickerItemView = viewHolder.pickerItemView;
        pickerItemView.initItem(imageItem, presenter, selectConfig);

        int indexOfSelectList = selectList.indexOf(imageItem);
        boolean isContainsThisItem = indexOfSelectList >= 0;
        final int finalDisableCode = PickerItemDisableCode.getItemDisableCode(imageItem, selectConfig,
                selectList, isContainsThisItem);
        if (pickerItemView.getCheckBoxView() != null) {
            pickerItemView.getCheckBoxView().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onActionResult != null) {
                        onActionResult.onCheckItem(imageItem, finalDisableCode);
                    } } }); }

        pickerItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onActionResult != null) {
                    onActionResult.onClickItem(imageItem, position, finalDisableCode);
                } } });

        pickerItemView.enableItem(imageItem, indexOfSelectList >= 0, indexOfSelectList);
        if (finalDisableCode != PickerItemDisableCode.NORMAL) {
            pickerItemView.disableItem(imageItem, finalDisableCode);
        } }

    // silme
    @Override
    public int getItemViewType(int position) {
        if (selectConfig.isShowCamera()) {
            return position == 0 ? ITEM_TYPE_CAMERA : ITEM_TYPE_NORMAL;
        }
        return ITEM_TYPE_NORMAL;
    }

    // silme
    @Override
    public int getItemCount() {
        return selectConfig.isShowCamera() ? images.size() + 1 : images.size();
    }

    // silme
    private ImageItem getItem(int position) {
        if (selectConfig.isShowCamera()) {
            if (position == 0) {
                return null;
            }
            return images.get(position - 1);
        } else {
            return images.get(position);
        }
    }

    // silme
    public void refreshData(List<ImageItem> items) {
        if (items != null && items.size() > 0) {
            images = items;
        }
        notifyDataSetChanged();
    }

    // silme
    static class ItemViewHolder extends RecyclerView.ViewHolder {
        private PickerItemView pickerItemView;
        private Context context;

        public static void setViewSize(View view, int i, float v) {
            WeakReference<View> viewWeakReference = new WeakReference<>(view);
            if (viewWeakReference.get() != null) {
                ViewGroup.LayoutParams params = view.getLayoutParams();
                if (params == null) {
                    params = new ViewGroup.LayoutParams(i, (int) (i / v));
                } else {
                    if (i != -1) {
                        params.width = i;
                    }
                    if (v != 0) {
                        params.height = (int) (i / v);
                    } }
                viewWeakReference.get().setLayoutParams(params);
            }
        }

        ItemViewHolder(@NonNull View itemView, boolean isCamera, BaseSelectConfig selectConfig, IPickerPresenter presenter, PickerUiConfig uiConfig) {
            super(itemView);
            context = itemView.getContext();
            FrameLayout layout = itemView.findViewById(R.id.mRoot);
            int width = (getScreenWidth() - 2) / selectConfig.getColumnCount();
            setViewSize(layout, width, 1.00f);

            pickerItemView = uiConfig.getPickerUiProvider().getItemView(context);
            layout.removeAllViews();
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            params.bottomMargin = 1;
            params.topMargin = 1;
            params.rightMargin = 1;
            params.leftMargin = 1;
            if (isCamera) {
                layout.addView(pickerItemView.getCameraView(selectConfig, presenter), params);
            } else {
                layout.addView(pickerItemView, params);
            }
        }

        int getScreenWidth() {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE); // buradan  bir hata alıyorum
            DisplayMetrics outMetrics = new DisplayMetrics();
            assert wm != null;
            wm.getDefaultDisplay().getMetrics(outMetrics);
            return outMetrics.widthPixels;
        }
    }

    // silme
    private OnActionResult onActionResult;

    // silme
    public void setOnActionResult(OnActionResult onActionResult) {
        this.onActionResult = onActionResult;
    }

    // silme
    public interface OnActionResult {
        /**
         * 点击操作
         *
         * @param imageItem 当前item
         * @param position  当前item的position
         */
        void onClickItem(ImageItem imageItem, int position, int disableItemCode);

        /**
         * 执行选中（取消选中）操作
         *
         * @param imageItem 当前item
         */
        void onCheckItem(ImageItem imageItem, int disableItemCode);
    }
}