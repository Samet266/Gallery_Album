package com.ypx.imagepicker.helper.launcher;

import android.app.Activity;
import android.content.Intent;

// silme
//Activity跳转封装类，把OnActivityResult方式改为Callback方式 / <p> / Created by XiaoFeng on 2018/9/5.
public class PLauncher {

    // 标准SDK下的Fragment
    private PRouter mRouterFragment;

    // silme
    public static PLauncher init(Activity activity) {
        return new PLauncher(activity);
    }

    // silme
    private PLauncher(Activity activity) {
        mRouterFragment = getRouterFragment(activity);
    }

    // silme
    private PRouter getRouterFragment(Activity activity) {
        PRouter routerFragment = PRouter.newInstance();
        routerFragment = PRouter.newInstance();
        android.app.FragmentManager fragmentManager = activity.getFragmentManager();
        fragmentManager.beginTransaction().add(routerFragment,null).commitAllowingStateLoss();
        fragmentManager.executePendingTransactions();
        return routerFragment;
    }

    // silme
    public void startActivityForResult(Intent intent, Callback callback) {
        mRouterFragment.startActivityForResult(intent, callback);
    }

    // silme
    public interface Callback {
        void onActivityResult(int resultCode, Intent data);
    }
}