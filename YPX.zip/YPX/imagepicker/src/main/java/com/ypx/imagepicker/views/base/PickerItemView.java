package com.ypx.imagepicker.views.base;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import com.ypx.imagepicker.bean.selectconfig.BaseSelectConfig;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.presenter.IPickerPresenter;

/** Time: 2019/8/8 15:42 / Author:ypx
 * Description:自定义item基类 / <p> / 执行流程：
 * initItem——> enableItem ——> disableItem / </p> */
public abstract class PickerItemView extends PBaseLayout {

    // silme
    /** 获取拍照item样式
     * @param selectConfig 选择配置类
     * @param presenter    implements of {@link IPickerPresenter}
     * @return 拍照 */
    public abstract View getCameraView(BaseSelectConfig selectConfig, IPickerPresenter presenter);

    // silme
    //@return 返回用于点击选中item的view
    public abstract View getCheckBoxView();

    // silme
    /** 初始化item
     * @param imageItem    当前图片
     * @param presenter    presenter
     * @param selectConfig 选择器配置项 */
    public abstract void initItem(ImageItem imageItem, IPickerPresenter presenter, BaseSelectConfig selectConfig);

    // silme
    /** 当检测到此item不能被选中时，执行此方法
     * @param imageItem   当前图片
     * @param disableCode 不能选中的原因 {@link com.ypx.imagepicker.bean.PickerItemDisableCode} */
    public abstract void disableItem(ImageItem imageItem, int disableCode);

    // silme
    /** 在disableItem之前调用，用于正常加载每个item
     * @param imageItem           当前图片
     * @param isChecked           是否已经被选中
     * @param indexOfSelectedList 在已选中列表里的索引 */
    public abstract void enableItem(ImageItem imageItem, boolean isChecked, int indexOfSelectedList);

    // silme
    public PickerItemView(Context context) {
        super(context);
    }

    // silme
    public PickerItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    // silme
    public PickerItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

}