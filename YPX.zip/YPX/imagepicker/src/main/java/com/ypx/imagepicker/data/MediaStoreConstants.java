package com.ypx.imagepicker.data;

import android.net.Uri;
import android.provider.MediaStore;

// silme
/** Time: 2019/10/29 20:38
 * Author:ypx
 * Description: */
class MediaStoreConstants {
    static final String MIME_TYPE = MediaStore.MediaColumns.MIME_TYPE;

    // silme
    static final String MEDIA_TYPE = MediaStore.Files.FileColumns.MEDIA_TYPE;

    // silme
    static final String DISPLAY_NAME = MediaStore.Files.FileColumns.DISPLAY_NAME;

    // silme
    static final int MEDIA_TYPE_VIDEO = MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

    // silme
    static final int MEDIA_TYPE_IMAGE = MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;

    // silme
    static final String WIDTH = MediaStore.Files.FileColumns.WIDTH;

    // silme
    static final String HEIGHT = MediaStore.Files.FileColumns.HEIGHT;

    // silme
    static final String DATE_MODIFIED = MediaStore.Files.FileColumns.DATE_MODIFIED;

    // silme
    static final String DURATION = MediaStore.MediaColumns.DURATION;

    // silme
    static final String SIZE = MediaStore.MediaColumns.SIZE;

    // silme
    static final String _ID = MediaStore.Files.FileColumns._ID;

    // silme
    static final String COLUMN_BUCKET_ID = "bucket_id";

    // silme
    static final String COLUMN_BUCKET_DISPLAY_NAME = "bucket_display_name";

    // silme
    static final String COLUMN_URI = "uri";

    // silme
    static final String COLUMN_COUNT = "count";

    // silme
    // @deprecated android 10 已废弃此常亮
    static final String DATA = MediaStore.MediaColumns.DATA;

    // silme
    static final Uri QUERY_URI = MediaStore.Files.getContentUri("external");

    // silme
    static final String BUCKET_ORDER_BY = MediaStore.MediaColumns.DATE_MODIFIED + " DESC";
}
