package com.ypx.imagepicker.utils;

import java.io.File;
import java.net.FileNameMap;
import java.net.URLConnection;

// silme
//Time: 2019/7/17 14:16 / Author:ypx / Description:文件工具类
public class PBitmapUtils {

    // silme
    public static String getMimeTypeFromPath(String path) {
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        return fileNameMap.getContentTypeFor(new File(path).getName());
    }
}