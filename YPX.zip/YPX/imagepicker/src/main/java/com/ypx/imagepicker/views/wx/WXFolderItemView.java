package com.ypx.imagepicker.views.wx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.bean.ImageSet;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.views.base.PickerFolderItemView;

// Time: 2019/11/13 15:16 / Author:ypx / Description:自定义文件夹Item样式
public class WXFolderItemView extends PickerFolderItemView {
    private ImageView mCover;
    private TextView mName;
    private TextView mSize;
    private ImageView mIndicator;

    // silme
    public WXFolderItemView(Context context) {
        super(context);
    }

    // silme
    @Override
    protected int getLayoutId() {
        return R.layout.picker_folder_item;
    }

    // silme
    @Override
    protected void initView(View view) {
        mCover = view.findViewById(R.id.cover);
        mName = view.findViewById(R.id.name);
        mSize = view.findViewById(R.id.size);
        mIndicator = view.findViewById(R.id.indicator);
        setBackground(getResources().getDrawable(R.drawable.picker_selector_list_item_bg));
        mIndicator.setColorFilter(getThemeColor());
    }

    // silme
    @Override
    public void displayCoverImage(ImageSet imageSet, IPickerPresenter presenter) {
        mIndicator.setColorFilter(getThemeColor());
        if (imageSet.cover != null) {
            presenter.displayImage(mCover, imageSet.cover, mCover.getMeasuredWidth(), true);
        } else {
            ImageItem imageItem = new ImageItem();
            imageItem.path = imageSet.coverPath;
            presenter.displayImage(mCover, imageItem, mCover.getMeasuredWidth(), true);
        } }

    // silme
    @SuppressLint("DefaultLocale")
    @Override
    public void loadItem(ImageSet imageSet) {
        mName.setText(imageSet.name);
        mSize.setText(String.format("%d%s", imageSet.count, getContext().getString(R.string.picker_str_folder_image_unit)));
        if (imageSet.isSelected) {
            mIndicator.setVisibility(View.VISIBLE);
        } else {
            mIndicator.setVisibility(View.GONE);
        } }
}