package com.ypx.imagepicker.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.content.ContextCompat;
import com.ypx.imagepicker.ImagePicker;

// silme
//Description: 权限工具类 / <p> / Author: peixing.yang / Date: 2019/3/1
public class PPermissionUtils {
    private Context context;

    // silme
    public static boolean hasStoragePermissions(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, ImagePicker.REQ_STORAGE);
                return false;
            } }
        return true;
    }

    // silme
    public PPermissionUtils(Context context) {
        this.context = context;
    }

}