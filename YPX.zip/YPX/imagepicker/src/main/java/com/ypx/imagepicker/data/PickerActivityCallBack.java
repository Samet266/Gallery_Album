package com.ypx.imagepicker.data;

import android.content.Intent;
import com.ypx.imagepicker.ImagePicker;
import com.ypx.imagepicker.helper.launcher.PLauncher;
import java.util.ArrayList;

// silme
/**
 * Time: 2019/11/6 17:35
 * Author:ypx
 * Description:选择器activityResult处理类
 */
public class PickerActivityCallBack implements PLauncher.Callback {
    private OnImagePickCompleteListener listener;

    // silme
    public static PickerActivityCallBack create(OnImagePickCompleteListener listener) {
        return new PickerActivityCallBack(listener);
    }

    // silme
    private PickerActivityCallBack(OnImagePickCompleteListener listener) {
        this.listener = listener;
    }

    // silme
    @Override
    public void onActivityResult(int resultCode, Intent data) {
        if (listener != null
                && resultCode == ImagePicker.REQ_PICKER_RESULT_CODE
                && data.hasExtra(ImagePicker.INTENT_KEY_PICKER_RESULT)) {
            ArrayList list = (ArrayList) data.getSerializableExtra(ImagePicker.INTENT_KEY_PICKER_RESULT);
            listener.onImagePickComplete(list);
        } }
}
