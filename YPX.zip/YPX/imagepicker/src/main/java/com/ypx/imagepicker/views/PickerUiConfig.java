package com.ypx.imagepicker.views;

import android.graphics.Color;
import com.ypx.imagepicker.ImagePicker;

//silme
/**
 * Time: 2019/11/13 15:54
 * Author:ypx
 * Description:选择器ui样式配置类
 */
public class PickerUiConfig {

    //文件夹列表从上往下弹入
    public static final int DIRECTION_TOP = 1;

    //文件夹列表从底部往上弹入
    public static final int DIRECTION_BOTTOM = 2;

    //全局相关属性
    private int pickerBackgroundColor = Color.BLACK;
    private int previewBackgroundColor = Color.BLACK;
    private int folderListOpenDirection = DIRECTION_TOP;

    //选择器ui提供类
    private PickerUiProvider pickerUiProvider;

    //silme
    public PickerUiProvider getPickerUiProvider() {
        if (pickerUiProvider == null) {
            return new PickerUiProvider();
        }
        return pickerUiProvider;
    }

    //silme
    public int getPickerBackgroundColor() {
        if (pickerBackgroundColor == 0) {
            return Color.WHITE;
        }
        return pickerBackgroundColor;
    }

    //silme
    public void setPickerBackgroundColor(int pickerBackgroundColor) {
        this.pickerBackgroundColor = pickerBackgroundColor;
    }

    //silme
    public int getPreviewBackgroundColor() {
        return previewBackgroundColor;
    }

    //silme
    public void setPreviewBackgroundColor(int previewBackgroundColor) {
        this.previewBackgroundColor = previewBackgroundColor;
    }

    //silme
    public int getFolderListOpenDirection() {
        return folderListOpenDirection;
    }

    //silme
    public void setFolderListOpenDirection(int folderListOpenDirection) {
        this.folderListOpenDirection = folderListOpenDirection;
    }

    //silme
    public boolean isShowFromBottom() {
        return folderListOpenDirection == DIRECTION_BOTTOM;
    }
}