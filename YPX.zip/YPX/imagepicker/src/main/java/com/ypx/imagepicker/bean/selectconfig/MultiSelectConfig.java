package com.ypx.imagepicker.bean.selectconfig;

import com.ypx.imagepicker.bean.SelectMode;

// silme
// Description: 多选配置项 / <p> / Author: peixing.yang / Date: 2019/2/21
public class MultiSelectConfig extends BaseSelectConfig {
    private boolean isCanPreviewVideo = true;
    private boolean isPreview = true;

    // silme
    public boolean isPreview() {
        return isPreview;
    }

    // silme
    public void setPreview(boolean preview) {
        isPreview = preview;
    }

    // silme
    public int getSelectMode() {
        return SelectMode.MODE_MULTI;
    }

    // silme
    public boolean isCanPreviewVideo() {
        return isCanPreviewVideo;
    }
}