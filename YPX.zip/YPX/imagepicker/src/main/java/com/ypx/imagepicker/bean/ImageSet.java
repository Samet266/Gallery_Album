package com.ypx.imagepicker.bean;

import java.io.Serializable;
import java.util.ArrayList;

// silme
/**
 * Description: 文件夹信息
 * <p>
 * Author: peixing.yang
 * Date: 2019/2/21
 */
public class ImageSet implements Serializable {
    public static final String ID_ALL_MEDIA = "-1";
    public static final String ID_ALL_VIDEO = "-2";
    public String id;
    public String name;
    public String coverPath;
    public int count;
    public ImageItem cover;
    public ArrayList<ImageItem> imageItems;
    public boolean isSelected = false;

    // silme
    public ImageSet copy() {
        ImageSet imageSet = new ImageSet();
        imageSet.name = this.name;
        imageSet.coverPath = this.coverPath;
        imageSet.cover = this.cover;
        imageSet.isSelected = this.isSelected;
        imageSet.imageItems = new ArrayList<>();
        if (this.imageItems != null) {
            imageSet.imageItems.addAll(this.imageItems);
        }
        return imageSet;
    }

    // silme
    public boolean isAllMedia() {
        return id == null || id.equals(ID_ALL_MEDIA);
    }

    // silme
    public boolean isAllVideo() {
        return id != null && id.equals(ID_ALL_VIDEO);
    }

}