package com.ypx.imagepicker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import androidx.fragment.app.FragmentActivity;
import com.ypx.imagepicker.activity.PickerActivityManager;
import com.ypx.imagepicker.activity.preview.MultiImagePreviewActivity;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.bean.ImageSet;
import com.ypx.imagepicker.bean.MimeType;
import com.ypx.imagepicker.bean.selectconfig.MultiSelectConfig;
import com.ypx.imagepicker.builder.MultiPickerBuilder;
import com.ypx.imagepicker.data.MediaItemsDataSource;
import com.ypx.imagepicker.data.MediaSetsDataSource;
import com.ypx.imagepicker.data.OnImagePickCompleteListener;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.utils.PPermissionUtils;
import java.util.ArrayList;
import java.util.Set;

// silme
/**
 * Description: 图片加载启动类
 * <p>
 * Author: peixing.yang
 * Date: 2019/2/28
 * 使用文档 ：https://github.com/yangpeixing/YImagePicker/wiki/Documentation_3.x
 */
public class ImagePicker {
    //选择返回的key
    public static final String INTENT_KEY_PICKER_RESULT = "pickerResult";
    //选择返回code
    public static final int REQ_PICKER_RESULT_CODE = 1433;
    //存储权限码
    public static final int REQ_STORAGE = 1432;


    // 是否选中原图
    public static boolean isOriginalImage = false;

    private static int themeColor = Color.RED;

    private static boolean previewWithHighQuality = false;

    // silme
    public static boolean isPreviewWithHighQuality() {
        return previewWithHighQuality;
    }

    //silme
    /** 微信样式多选
     * @param presenter 选择器UI提供者
     * @return 微信样式多选 */
    public static MultiPickerBuilder withMulti(IPickerPresenter presenter) {
        return new MultiPickerBuilder(presenter);
    }


    //silme
    public static <T> void preview(Activity context, final IPickerPresenter presenter, ArrayList<T> imageList,
                                   int pos, final OnImagePickCompleteListener listener) {
        MultiSelectConfig selectConfig = new MultiSelectConfig();
        selectConfig.setMaxCount(imageList.size());
        MultiImagePreviewActivity.intent(context, null, transitArray(context, imageList),
                selectConfig, presenter, pos, new MultiImagePreviewActivity.PreviewResult() {
                    @Override
                    public void onResult(ArrayList<ImageItem> imageItems, boolean isCancel) {
                        if (listener != null) {
                            if (isCancel && listener instanceof OnImagePickCompleteListener) {}
                            else {
                                listener.onImagePickComplete(imageItems);
                            }
                        }
                    }
                });
    }

    //silme
    public static <T> ArrayList<ImageItem> transitArray(Activity activity, ArrayList<T> imageList) {
        ArrayList<ImageItem> items = new ArrayList<>();
        for (T t : imageList) {
                ImageItem imageItem = ImageItem.withPath(activity, (String) t);
                items.add(imageItem);
        }
        return items;
    }

    //silme
    public static void provideMediaSets(FragmentActivity activity, Set<MimeType> mimeTypeSet,
                                        MediaSetsDataSource.MediaSetProvider provider) {
        if (PPermissionUtils.hasStoragePermissions(activity)) {
            MediaSetsDataSource.create(activity).setMimeTypeSet(mimeTypeSet).loadMediaSets(provider);
        }
    }

    //silme
    public static void provideMediaItemsFromSetWithPreload(FragmentActivity activity, ImageSet set,
                                                           MediaItemsDataSource.MediaItemProvider provider) {
        if (PPermissionUtils.hasStoragePermissions(activity)) {
            MediaItemsDataSource dataSource = MediaItemsDataSource.create(activity, set);
            dataSource.loadMediaItems(provider);
        }
    }

    //silme
    public static void closePickerWithCallback(ArrayList<ImageItem> list) {
        Activity activity = PickerActivityManager.getLastActivity();
        Intent intent = new Intent();
        intent.putExtra(ImagePicker.INTENT_KEY_PICKER_RESULT, list);
        activity.setResult(ImagePicker.REQ_PICKER_RESULT_CODE, intent);
        activity.finish();
    }
}