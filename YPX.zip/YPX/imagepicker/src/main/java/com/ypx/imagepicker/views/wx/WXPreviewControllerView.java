package com.ypx.imagepicker.views.wx;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.ypx.imagepicker.ImagePicker;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.adapter.MultiPreviewAdapter;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.bean.PickerItemDisableCode;
import com.ypx.imagepicker.bean.selectconfig.BaseSelectConfig;
import com.ypx.imagepicker.bean.selectconfig.MultiSelectConfig;
import com.ypx.imagepicker.views.PickerUiConfig;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.utils.PCornerUtils;
import com.ypx.imagepicker.utils.PStatusBarUtil;
import com.ypx.imagepicker.views.base.PickerControllerView;
import com.ypx.imagepicker.views.base.PreviewControllerView;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
public class WXPreviewControllerView extends PreviewControllerView {
    private RecyclerView mPreviewRecyclerView;
    private RelativeLayout mBottomBar;
    private CheckBox mSelectCheckBox;
    private MultiPreviewAdapter previewAdapter;
    private IPickerPresenter presenter;
    private BaseSelectConfig selectConfig;
    private PickerUiConfig uiConfig;
    private ArrayList<ImageItem> selectedList;
    private FrameLayout mTitleContainer;
    private boolean isShowBottomBar = true;

    // silme
    public WXPreviewControllerView(Context context) {
        super(context);
    }

    // silme
    @Override
    protected int getLayoutId() {
        return R.layout.picker_wx_preview_bottombar;
    }

    // silme
    @Override
    protected void initView(View view) {
        mPreviewRecyclerView = view.findViewById(R.id.mPreviewRecyclerView);
        mBottomBar = view.findViewById(R.id.bottom_bar);
        mSelectCheckBox = view.findViewById(R.id.mSelectCheckBox);
        mTitleContainer = view.findViewById(R.id.mTitleContainer);
        mBottomBar.setClickable(true);
        setSelectCheckBoxDrawable(R.mipmap.picker_wechat_unselect, R.mipmap.picker_wechat_select);
        mSelectCheckBox.setText(getContext().getString(R.string.picker_str_bottom_choose));
    }

    // silme
    @Override
    public View getItemView(Fragment fragment, ImageItem imageItem, IPickerPresenter presenter) {
        return super.getItemView(fragment, imageItem, presenter);
    }

    // silme
    @Override
    public void setStatusBar() {
        mTitleContainer.setPadding(0, PStatusBarUtil.getStatusBarHeight(getContext()), 0, 0);
        PStatusBarUtil.setStatusBar((Activity) getContext(), Color.TRANSPARENT, true, PStatusBarUtil.isDarkColor(getResources().getColor(R.color.white_F5)));
    }

    // silme
    @Override
    public void initData(BaseSelectConfig selectConfig, IPickerPresenter presenter, PickerUiConfig uiConfig, ArrayList<ImageItem> selectedList) {
        this.selectConfig = selectConfig;
        this.presenter = presenter;
        this.selectedList = selectedList;
        this.uiConfig = uiConfig;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////

        titleBar = uiConfig.getPickerUiProvider().getTitleBar(getContext());
        if (titleBar == null) {
            titleBar = new WXTitleBar(getContext());
        }
        mTitleContainer.addView(titleBar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        mSelectCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    mSelectCheckBox.setChecked(false);
                    selectedList.remove(currentImageItem);
                } else {
                    int disableCode = PickerItemDisableCode.getItemDisableCode(currentImageItem, selectConfig, selectedList,
                            selectedList.contains(currentImageItem));

                    if (disableCode != PickerItemDisableCode.NORMAL) {
                        String message = PickerItemDisableCode.getMessageFormCode(getContext(), disableCode, presenter, selectConfig);
                        if (message.length() > 0) {
                            presenter.tip(new WeakReference<>(getContext()).get(), message);
                        }
                        mSelectCheckBox.setChecked(false);
                        return;
                    }
                    if (!selectedList.contains(currentImageItem)) {
                        selectedList.add(currentImageItem);
                    }
                    mSelectCheckBox.setChecked(true);
                }

                titleBar.refreshCompleteViewState(selectedList, selectConfig);
                previewAdapter.setPreviewImageItem(currentImageItem);
            }
        });

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////

        mPreviewRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false));
        previewAdapter = new MultiPreviewAdapter(selectedList, presenter);
        mPreviewRecyclerView.setAdapter(previewAdapter);
    }

    private PickerControllerView titleBar;

    // silme
    @Override
    public View getCompleteView() {
        return titleBar.getCanClickToCompleteView();
    }

    // silme
    @Override
    public void singleTap() {
        if (mTitleContainer.getVisibility() == View.VISIBLE) {
            mTitleContainer.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_top_out));
            mTitleContainer.setVisibility(View.GONE);
            if (isShowBottomBar) {
                mBottomBar.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_fade_out));
                mBottomBar.setVisibility(View.GONE);
                mPreviewRecyclerView.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_fade_out));
                mPreviewRecyclerView.setVisibility(View.GONE);
            }
        } else {
            mTitleContainer.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_top_in));
            mTitleContainer.setVisibility(View.VISIBLE);
            if (isShowBottomBar) {
                mBottomBar.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_fade_in));
                mBottomBar.setVisibility(View.VISIBLE);
                mPreviewRecyclerView.setAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.picker_fade_in));
                mPreviewRecyclerView.setVisibility(View.VISIBLE);
            }
        }
    }

    private ImageItem currentImageItem;

    // silme
    @SuppressLint("DefaultLocale")
    @Override
    public void onPageSelected(int position, ImageItem imageItem, int totalPreviewCount) {
        this.currentImageItem = imageItem;
        mSelectCheckBox.setChecked(selectedList.contains(imageItem));
        previewAdapter.setPreviewImageItem(imageItem);
        titleBar.refreshCompleteViewState(selectedList, selectConfig);
    }

    // silme
    public void setSelectCheckBoxDrawable(int unCheckDrawableID, int checkedDrawableID) {
        PCornerUtils.setCheckBoxDrawable(mSelectCheckBox, checkedDrawableID, unCheckDrawableID);
    }
}