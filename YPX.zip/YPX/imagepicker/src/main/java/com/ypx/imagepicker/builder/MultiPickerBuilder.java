package com.ypx.imagepicker.builder;

import android.app.Activity;
import android.os.Bundle;
import com.ypx.imagepicker.activity.multi.MultiImagePickerActivity;
import com.ypx.imagepicker.activity.multi.MultiImagePickerFragment;
import com.ypx.imagepicker.bean.selectconfig.MultiSelectConfig;
import com.ypx.imagepicker.data.OnImagePickCompleteListener;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import static com.ypx.imagepicker.activity.multi.MultiImagePickerActivity.INTENT_KEY_SELECT_CONFIG;
import static com.ypx.imagepicker.activity.multi.MultiImagePickerActivity.INTENT_KEY_PRESENTER;

// silme
/** Description: 多选选择器构造类 / <p> / Author: peixing.yang
 * Date: 2018/9/19 16:56 */
public class MultiPickerBuilder {
    private MultiSelectConfig selectConfig;
    private IPickerPresenter presenter;

    // silme
    public MultiPickerBuilder(IPickerPresenter presenter) {
        this.presenter = presenter;
        this.selectConfig = new MultiSelectConfig();
    }

    // silme
    public MultiPickerBuilder setMaxCount(int selectLimit) {
        selectConfig.setMaxCount(selectLimit);
        return this;
    }

    // silme
    // @param duration 设置视频可选择的最大时长
    public MultiPickerBuilder setMaxVideoDuration(long duration) {
        this.selectConfig.setMaxVideoDuration(duration);
        return this;
    }

    // silme
    //@param duration 设置视频可选择的最小时长
    public MultiPickerBuilder setMinVideoDuration(long duration) {
        this.selectConfig.setMinVideoDuration(duration);
        return this;
    }

    // silme
    //@param columnCount 设置列数
    public MultiPickerBuilder setColumnCount(int columnCount) {
        selectConfig.setColumnCount(columnCount);
        return this;
    }

    //—————————————————————— 以上为单图剪裁的属性 ——————————————————————

    // silme
    //@param config 选择配置
    public MultiPickerBuilder withMultiSelectConfig(MultiSelectConfig config) {
        this.selectConfig = config;
        return this;
    }

    // silme
    /** fragment模式调用
     * @param completeListener 选择回调
     * @return MultiImagePickerFragment */
    public MultiImagePickerFragment pickWithFragment(OnImagePickCompleteListener completeListener) {
        MultiImagePickerFragment mFragment = new MultiImagePickerFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(INTENT_KEY_SELECT_CONFIG, selectConfig);
        bundle.putSerializable(INTENT_KEY_PRESENTER, presenter);
        mFragment.setArguments(bundle);
        mFragment.setOnImagePickCompleteListener(completeListener);
        return mFragment;
    }

    // silme
    /** 直接开启相册选择
     * @param context  页面调用者
     * @param listener 选择器选择回调 */
    public void pick(Activity context, final OnImagePickCompleteListener listener) {
        if (selectConfig.getMimeTypes() == null || selectConfig.getMimeTypes().size() == 0) {
            return;
        }
        MultiImagePickerActivity.intent(context, selectConfig, presenter, listener);
    }
}