package com.ypx.imagepicker.bean.selectconfig;

import android.content.Context;
import com.ypx.imagepicker.bean.MimeType;
import com.ypx.imagepicker.utils.PDateUtil;
import java.io.Serializable;
import java.util.Set;

// silme
// Time: 2019/9/30 11:05 / Author:ypx / Description: 配置类基类
public class BaseSelectConfig implements Serializable {
    private int maxCount;
    private long minVideoDuration = 0;
    private long maxVideoDuration = 1200000000L;
    private int columnCount = 4;
    private boolean isShowCamera;
    private boolean isShowCameraInAllMedia;

    // silme
    public boolean isShowCameraInAllMedia() {
        return isShowCameraInAllMedia;
    }

    // silme
    // 图片和视频只能选择一个
    public boolean isSinglePickImageOrVideoType() {
        return false;
    }

    // silme
    public long getMinVideoDuration() {
        return minVideoDuration;
    }

    // silme
    public void setMinVideoDuration(long minVideoDuration) {
        this.minVideoDuration = minVideoDuration;
    }

    // silme
    public long getMaxVideoDuration() {
        return maxVideoDuration;
    }

    // silme
    public String getMaxVideoDurationFormat(Context context) {
        return PDateUtil.formatTime(context, maxVideoDuration);
    }

    // silme
    public String getMinVideoDurationFormat(Context context) {
        return PDateUtil.formatTime(context, minVideoDuration);
    }

    // silme
    public void setMaxVideoDuration(long maxVideoDuration) {
        this.maxVideoDuration = maxVideoDuration;
    }

    // silme
    public int getColumnCount() {
        return columnCount;
    }

    // silme
    public void setColumnCount(int columnCount) {
        this.columnCount = columnCount;
    }

    // silme
    public int getMaxCount() {
        return maxCount;
    }

    // silme
    public void setMaxCount(int maxCount) {
        this.maxCount = maxCount;
    }

    // silme
    public boolean isShowCamera() {
        return isShowCamera;
    }

    // silme
    public void setShowCamera(boolean showCamera) {
        isShowCamera = showCamera;
    }

    // silme
    public boolean isVideoSinglePick() {
        return true;
    }

    // silme
    public boolean isShowVideo() {
        return true;
    }

    // silme
    public boolean isShowImage() {
        return true;
    }

    // silme
    public Set<MimeType> getMimeTypes() {
        return MimeType.ofAll();
    }

    // silme
    public boolean isSinglePickAutoComplete() {
        return false;
    }

    // silme
    public boolean isVideoSinglePickAndAutoComplete() {
        return isVideoSinglePick() && isSinglePickAutoComplete();
    }
}