package com.ypx.imagepicker.utils;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.widget.CheckBox;

// Utils to get corner drawable
public class PCornerUtils {

    /// silme
    public static Drawable cornerDrawable(final int bgColor, float cornerradius) {
        final GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        return bg;
    }

    /// silme
    public static void setCheckBoxDrawable(CheckBox checkBox, int selectedDrawableID, int unSelectedDrawableID) {
        StateListDrawable checkBoxDrawable = new StateListDrawable();
        checkBoxDrawable.addState(new int[]{android.R.attr.state_selected},checkBox.getResources().getDrawable(selectedDrawableID) );
        checkBoxDrawable.addState(new int[]{android.R.attr.state_checked}, checkBox.getResources().getDrawable(selectedDrawableID));
        checkBoxDrawable.addState(new int[]{}, checkBox.getResources().getDrawable(unSelectedDrawableID));
        checkBox.setCompoundDrawablesWithIntrinsicBounds(checkBoxDrawable, null, null, null);
    }

    /// silme
    public static void setCheckBoxDrawable(CheckBox checkBox, Drawable selectedDrawable, Drawable unSelectedDrawable) {
        StateListDrawable checkBoxDrawable = new StateListDrawable();
        checkBoxDrawable.addState(new int[]{android.R.attr.state_selected},selectedDrawable);
        checkBoxDrawable.addState(new int[]{android.R.attr.state_checked}, selectedDrawable);
        checkBoxDrawable.addState(new int[]{}, unSelectedDrawable);
        checkBox.setCompoundDrawablesWithIntrinsicBounds(checkBoxDrawable, null, null, null);
    }
}