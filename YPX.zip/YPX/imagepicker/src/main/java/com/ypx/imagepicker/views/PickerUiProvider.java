package com.ypx.imagepicker.views;

import android.content.Context;
import com.ypx.imagepicker.views.wx.WXBottomBar;
import com.ypx.imagepicker.views.wx.WXItemView;
import com.ypx.imagepicker.views.wx.WXTitleBar;
import com.ypx.imagepicker.views.base.PickerControllerView;
import com.ypx.imagepicker.views.base.PickerItemView;

//silme
/**
 * Time: 2019/10/27 22:22
 * Author:ypx
 * Description: 选择器UI提供类,默认为微信样式
 */
public class PickerUiProvider {

    //silme
    /** 获取标题栏
     *@param context 调用此view的activity
     * @return {@link PickerControllerView}对象，参考{@link WXTitleBar}*/
    public PickerControllerView getTitleBar(Context context) {
        return new WXTitleBar(context);
    }

    //silme
    /** 获取底部栏
     * @param context 调用此view的activity
     * @return {@link PickerControllerView}对象，参考{@link WXBottomBar} */
    public PickerControllerView getBottomBar(Context context) {
        return new WXBottomBar(context);
    }

    //silme
    /** 获取自定义item
     * @param context 调用此view的activity
     *  @return {@link PickerItemView}对象，参考{@link WXBottomBar}*/
    public PickerItemView getItemView(Context context) {
        return new WXItemView(context);
    }
}