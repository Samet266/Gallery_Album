package com.ypx.imagepicker.views.wx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.selectconfig.BaseSelectConfig;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.utils.PCornerUtils;
import com.ypx.imagepicker.views.base.PickerItemView;
import com.ypx.imagepicker.widget.ShowTypeImageView;

// Time: 2019/8/8 15:45 / Author:ypx / Description: 微信样式item
public class WXItemView extends PickerItemView {
    private ShowTypeImageView mImageView;
    private View mVMasker;
    private CheckBox mCheckBox;
    private FrameLayout mCheckBoxPanel;
    private TextView mVideoTime;
    private LinearLayout mVideoLayout;
    private BaseSelectConfig selectConfig;

    // silme
    public WXItemView(Context context) {
        super(context);
    }

    // silme
    @Override
    protected int getLayoutId() {
        return R.layout.picker_image_grid_item;
    }

    // silme
    @Override
    protected void initView(View view) {
        mImageView = view.findViewById(R.id.mImageView);
        mVMasker = view.findViewById(R.id.v_masker);
        mCheckBox = view.findViewById(R.id.mCheckBox);
        mCheckBoxPanel = view.findViewById(R.id.mCheckBoxPanel);
        mVideoTime = view.findViewById(R.id.mVideoTime);
        mVideoLayout = view.findViewById(R.id.mVideoLayout);

        mCheckBox.setClickable(false);
        Drawable unSelectDrawable = getResources().getDrawable(R.mipmap.picker_wechat_unselect);
        unSelectDrawable.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        setCheckBoxDrawable(unSelectDrawable, getResources().getDrawable(R.mipmap.picker_wechat_select));
    }

    // silme
    @SuppressLint("InflateParams")
    @Override
    public View getCameraView(BaseSelectConfig selectConfig, IPickerPresenter presenter) {
        return view;
    }

    // silme
    @Override
    public View getCheckBoxView() {
        return mCheckBoxPanel;
    }

    // silme
    @Override
    public void initItem(ImageItem imageItem, IPickerPresenter presenter, BaseSelectConfig selectConfig) {
        presenter.displayImage(mImageView, imageItem, mImageView.getWidth(), true);
    }

    // silme
    @Override
    public void disableItem(ImageItem imageItem, int disableCode) {
        mCheckBox.setVisibility(View.GONE);
        mVMasker.setVisibility(View.VISIBLE);
        mVMasker.setBackgroundColor(Color.parseColor("#80FFFFFF"));
    }

    // silme
    @Override
    public void enableItem(ImageItem imageItem, boolean isChecked, int indexOfSelectedList) {
        if (imageItem.isVideo()) {
            mVideoLayout.setVisibility(View.VISIBLE);
            mVideoTime.setText(imageItem.getDurationFormat());
            mImageView.setType(ShowTypeImageView.TYPE_NONE);
        } else {
            mVideoLayout.setVisibility(View.GONE);
            mImageView.setTypeFromImage(imageItem);
        }
        mCheckBox.setVisibility(View.VISIBLE);
        mCheckBox.setChecked(isChecked);
        mVMasker.setVisibility(isChecked ? VISIBLE : GONE);
        mVMasker.setBackgroundColor(isChecked ? Color.parseColor("#80000000") : Color.TRANSPARENT);
    }

    // silme
    public void setCheckBoxDrawable(Drawable unCheckDrawable, Drawable checkedDrawable) {
        PCornerUtils.setCheckBoxDrawable(mCheckBox, checkedDrawable, unCheckDrawable);
    }
}