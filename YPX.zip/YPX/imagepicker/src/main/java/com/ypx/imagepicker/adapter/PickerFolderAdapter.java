package com.ypx.imagepicker.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.ImageSet;
import com.ypx.imagepicker.views.PickerUiConfig;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.views.wx.WXFolderItemView;
import com.ypx.imagepicker.views.base.PickerFolderItemView;
import java.util.ArrayList;
import java.util.List;

// silme
/**
 * Time: 2018/4/6 10:47
 * Author:yangpeixing
 * Description: 文件夹adapter
 */
public class PickerFolderAdapter extends RecyclerView.Adapter<PickerFolderAdapter.ViewHolder> {
    private List<ImageSet> mImageSets = new ArrayList<>();
    private IPickerPresenter presenter;
    private PickerUiConfig uiConfig;

    // silme
    public PickerFolderAdapter(IPickerPresenter presenter, PickerUiConfig uiConfig) {
        this.presenter = presenter;
        this.uiConfig = uiConfig;
    }

    // silme
    public void refreshData(List<ImageSet> folders) {
        mImageSets.clear();
        mImageSets.addAll(folders);
        notifyDataSetChanged();
    }

    // silme
    private ImageSet getItem(int i) {
        return mImageSets.get(i);
    }

    // silme
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.picker_item_root, parent, false);
        return new ViewHolder(view, uiConfig);
    }

    // silme
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        ImageSet imageSet = getItem(position);
        PickerFolderItemView pickerFolderItemView = holder.pickerFolderItemView;
        pickerFolderItemView.displayCoverImage(imageSet, presenter);
        pickerFolderItemView.loadItem(imageSet);
        pickerFolderItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (folderSelectResult != null) {
                    folderSelectResult.folderSelected(getItem(position), position);
                } } }); }

    // silme
    @Override
    public int getItemCount() {
        return mImageSets.size();
    }

    // silme
    class ViewHolder extends RecyclerView.ViewHolder {
        private PickerFolderItemView pickerFolderItemView;

        ViewHolder(View view, PickerUiConfig uiConfig) {
            super(view);
            if (pickerFolderItemView == null) {
                pickerFolderItemView = new WXFolderItemView(view.getContext());
            }
            FrameLayout layout = itemView.findViewById(R.id.mRoot);
            layout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    0 > 0 ? null : ViewGroup.LayoutParams.WRAP_CONTENT));
            layout.removeAllViews();
            layout.addView(pickerFolderItemView);
        } }

    // silme
    private FolderSelectResult folderSelectResult;

    // silme
    public void setFolderSelectResult(FolderSelectResult folderSelectResult) {
        this.folderSelectResult = folderSelectResult;
    }

    // silme
    public interface FolderSelectResult {
        void folderSelected(ImageSet set, int pos);
    }
}