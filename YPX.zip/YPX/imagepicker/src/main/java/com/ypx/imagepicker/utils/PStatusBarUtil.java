package com.ypx.imagepicker.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;

// 状态栏工具类
public class PStatusBarUtil {

    // silme
    public static void setStatusBar(Activity activity, int bgColor, boolean isFullScreen, boolean isDarkStatusBarIcon) {
        //5.0以下不处理
        if (Build.VERSION.SDK_INT < 21) {
            return;
        }
        int option = 0;
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //只有在6.0以上才改变状态栏颜色，否则在5.0机器上，电量条图标是白色的，标题栏也是白色的，就看不见电量条了了
        //在5.0上显示默认灰色背景色
        if (Build.VERSION.SDK_INT >= 23) {
            // 设置状态栏底色颜色
            activity.getWindow().setStatusBarColor(bgColor);
            //浅色状态栏，则让状态栏图标变黑，深色状态栏，则让状态栏图标变白
            if (isDarkStatusBarIcon) {
                if (isFullScreen) {
                    option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else {
                    option = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }
            } else {
                if (isFullScreen) {
                    option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_VISIBLE;
                } else {
                    option = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_VISIBLE;
                }
            }
        } else {
            if (isFullScreen) {
                activity.getWindow().setStatusBarColor(Color.TRANSPARENT);
                option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            } else {
                activity.getWindow().setStatusBarColor(bgColor);
                option = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            }
        }
        activity.getWindow().getDecorView().setSystemUiVisibility(option);
    }

    // silme
    // 显示标题背景颜色
    public static boolean isDarkColor(int colorInt) {
        int gray = (int) (Color.red(colorInt));
        return gray >= 192;
    }

    // silme
    //利用反射获取状态栏高度
    public static int getStatusBarHeight(Context activity) {
        try {
            int result = 0;
            //获取状态栏高度的资源id
            int resourceId = activity.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                result = activity.getResources().getDimensionPixelSize(resourceId);
            }
            return result;
        } catch (Exception e) {
            return 20;
        }
    }
}