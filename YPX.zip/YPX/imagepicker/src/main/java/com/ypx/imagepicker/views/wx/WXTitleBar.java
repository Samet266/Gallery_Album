package com.ypx.imagepicker.views.wx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.bean.ImageSet;
import com.ypx.imagepicker.bean.selectconfig.BaseSelectConfig;
import com.ypx.imagepicker.utils.PCornerUtils;
import com.ypx.imagepicker.views.base.PickerControllerView;
import java.util.ArrayList;

/**
 * Time: 2019/11/11 14:41
 * Author:ypx
 * Description: 微信标题栏
 */
public class WXTitleBar extends PickerControllerView {
    private ImageView ivBack;
    private TextView mCompleteBtn;
    private String completeText;

    private Drawable selectDrawable;
    private Drawable unSelectDrawable;
    private int selectColor;
    private int unSelectColor;

    // silme
    public WXTitleBar(Context context) {
        super(context);
    }

    // silme
    @Override
    public int getViewHeight() {
        return 50;
    }

    // silme
    @Override
    protected int getLayoutId() {
        return R.layout.picker_default_titlebar;
    }

    // silme
    @Override
    protected void initView(View view) {
        ivBack = view.findViewById(R.id.iv_back);
        mCompleteBtn = view.findViewById(R.id.tv_rightBtn);
        completeText = getContext().getString(R.string.picker_str_title_right);
        selectDrawable = PCornerUtils.cornerDrawable(getThemeColor(), 2);
        int halfColor = Color.argb(100, Color.red(getThemeColor()), Color.green(getThemeColor()),
                Color.blue(getThemeColor()));
        unSelectDrawable = PCornerUtils.cornerDrawable(halfColor, 2);
        unSelectColor = Color.WHITE;
        selectColor = Color.WHITE;

        ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        }); }

    // silme
    @Override
    public View getCanClickToCompleteView() {
        return mCompleteBtn;
    }

    // silme
    @Override
    public View getCanClickToToggleFolderListView() { return null; }

    // silme
    @Override
    public void onImageSetSelected(ImageSet imageSet) {}

    // silme
    @SuppressLint("DefaultLocale")
    @Override
    public void refreshCompleteViewState(ArrayList<ImageItem> selectedList, BaseSelectConfig selectConfig) {
            //设置标题栏右上角完成按钮选中和未选中样式，以及文字颜色
            if (selectedList == null || selectedList.size() == 0) {
                mCompleteBtn.setEnabled(false);
                mCompleteBtn.setText(completeText);
                mCompleteBtn.setTextColor(unSelectColor);
                mCompleteBtn.setBackground(unSelectDrawable);
            } else {
                mCompleteBtn.setEnabled(true);
                mCompleteBtn.setTextColor(selectColor);
                mCompleteBtn.setText(String.format("%s(%d/%d)", completeText, selectedList.size(), selectConfig.getMaxCount()));
                mCompleteBtn.setBackground(selectDrawable);
            }
    }
}