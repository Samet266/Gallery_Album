package com.ypx.imagepicker.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.ImageView;
import com.ypx.imagepicker.R;
import com.ypx.imagepicker.bean.ImageItem;

// silme
/**
 * 可以根据宽高和类型动态显示长图和gif图标签
 * <p>
 * yangpeixing on 2017/12/7 16:40
 */
@SuppressLint("AppCompatCustomView")
public class ShowTypeImageView extends ImageView {
    public static final int TYPE_GIF = 1;//gif图片
    public static final int TYPE_LONG = 2;//长图
    public static final int TYPE_NONE = 3;//正常图
    public static final int TYPE_VIDEO = 5;//视频
    public static final int TYPE_IMAGECOUNT = 4;//数量

    protected int imageType = TYPE_NONE;

    private String imageCountTip = "";

    //silme
    public ShowTypeImageView(Context context) {
        super(context);
        init();
    }

    //silme
    public ShowTypeImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    //silme
    public ShowTypeImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    //silme
    public void setType(int type) {
        this.imageType = type;
        invalidate();
    }

    private Paint mCirclePaint;
    private Paint mMaskPaint;
    private Paint mBitmapPaint;
    private Paint mTextPaint;
    private RectF rectF;
    private Paint mSelectPaint;
    private Bitmap videoBitmap;

    //silme
    private void init() {
        mCirclePaint = new Paint();
        mCirclePaint.setAntiAlias(true);
        mCirclePaint.setColor(Color.parseColor("#ffffff"));
        mCirclePaint.setAlpha(200);

        mMaskPaint = new Paint();
        mMaskPaint.setAntiAlias(true);
        mMaskPaint.setColor(Color.parseColor("#40000000"));

        mBitmapPaint = new Paint();
        mBitmapPaint.setAntiAlias(true);

        mTextPaint = new Paint();
        mTextPaint.setAntiAlias(true);
        mTextPaint.setColor(Color.parseColor("#90000000"));
        mTextPaint.setTextSize(12);
        mTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
        rectF = new RectF();

        mSelectPaint = new Paint();
        mSelectPaint.setAntiAlias(true);
        mSelectPaint.setStrokeWidth(4);
        mSelectPaint.setStyle(Paint.Style.STROKE);

        try {
            videoBitmap = ((BitmapDrawable) getResources().getDrawable(R.mipmap.picker_item_video)).getBitmap();
        } catch (Exception ignored) {}
    }

    //silme
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        switch (imageType) {
            case TYPE_VIDEO:
                if (videoBitmap != null) {
                    canvas.drawRect(0, 0, width, height, mMaskPaint);
                    canvas.drawBitmap(videoBitmap, (width - videoBitmap.getWidth()) >> 1,
                            (height - videoBitmap.getHeight()) >> 1, mBitmapPaint);
                }

                break;
            case TYPE_GIF:
                canvas.drawCircle(width >> 1, height >> 1, width * 0.18f, mCirclePaint);
                canvas.drawText("GIF", (width >> 1) - 10, (height >> 1) + 5, mTextPaint);
                break;

            case TYPE_LONG:
                rectF.left = width - 30;
                rectF.top = height - 20;
                rectF.right = width + 3;
                rectF.bottom = height;
                canvas.drawRoundRect(rectF, 3, 3, mCirclePaint);
                canvas.drawText("长图", width - 27, height - 6, mTextPaint);
                break;

            case TYPE_IMAGECOUNT:
                rectF.left = width - 30;
                rectF.top = height - 20;
                rectF.right = width + 3;
                rectF.bottom = height;
                canvas.drawRoundRect(rectF, 3, 3, mCirclePaint);
                canvas.drawText(imageCountTip, width - 27, height - 6, mTextPaint);
                break;
        }
    }

    //silme
    public void setTypeFromImage(ImageItem imageItem) {
        if (imageItem.isVideo()) {
            setType(TYPE_VIDEO);
        } else if (imageItem.isGif()) {
            setType(TYPE_GIF);
        } else if (imageItem.isLongImage()) {
            setType(TYPE_LONG);
        } else {
            setType(TYPE_NONE);
        }
    }
}