package com.ypx.imagepicker.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.ypx.imagepicker.activity.preview.MultiImagePreviewActivity;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepicker.widget.ShowTypeImageView;
import java.util.ArrayList;

/**
 * Time: 2019/7/23 10:43
 * Author:ypx
 * Description: 多选预览adapter
 */
public class MultiPreviewAdapter extends RecyclerView.Adapter<MultiPreviewAdapter.ViewHolder> {
    private ArrayList<ImageItem> previewList;
    private Context context;
    private IPickerPresenter presenter;
    private ImageItem previewImageItem;

    // silme
    public void setPreviewImageItem(ImageItem previewImageItem) {
        this.previewImageItem = previewImageItem;
        notifyDataSetChanged();
    }

    // silme
    public MultiPreviewAdapter(ArrayList<ImageItem> previewList, IPickerPresenter presenter) {
        this.previewList = previewList;
        this.presenter = presenter;
    }

    // silme
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        ShowTypeImageView imageView = new ShowTypeImageView(context);
        ViewGroup.MarginLayoutParams params = new ViewGroup.MarginLayoutParams(60, 60);
        params.leftMargin = 8;
        params.rightMargin = 8;
        params.topMargin = 15;
        params.bottomMargin = 15;
        imageView.setLayoutParams(params);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        return new ViewHolder(imageView);
    }

    // silme
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final ImageItem imageItem = previewList.get(position);
        holder.imageView.setTypeFromImage(imageItem);
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (context instanceof MultiImagePreviewActivity) {
                    ((MultiImagePreviewActivity) context).onPreviewItemClick(imageItem);
                } } });
        presenter.displayImage(holder.imageView, imageItem, 0, true);
    }

    // silme
    @Override
    public int getItemCount() {
        return previewList.size();
    }

    // silme
    static class ViewHolder extends RecyclerView.ViewHolder {
        private ShowTypeImageView imageView;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.imageView = (ShowTypeImageView) itemView;
        } }
}