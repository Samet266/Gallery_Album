package com.ypx.imagepickerdemo.Video;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.ypx.imagepicker.ImagePicker;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.data.OnImagePickCompleteListener;
import com.ypx.imagepicker.presenter.IPickerPresenter;
import com.ypx.imagepickerdemo.MainActivityView;
import com.ypx.imagepickerdemo.style.WeChatPresenter;
import java.util.ArrayList;

public class PortraitCameraActivity extends AppCompatActivity  implements MainActivityView.MainViewCallBack {

    private MainActivityView mainActivityView;
    private WeChatPresenter weChatPresenter;

    // silme
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        weChatPresenter = new WeChatPresenter();
        mainActivityView = MainActivityView.create(this, this);
    }

    // silme
    // gallery inin kendisi
    @Override
    public void weChatPick(int count) {
        IPickerPresenter presenter = weChatPresenter;
        ImagePicker.withMulti(presenter)//指定presenter
                .setMaxCount(count)//设置选择的最大数
                .setColumnCount(3)//设置列数
                .setMaxVideoDuration(120000L)//设置视频可选取的最大时长
                .setMinVideoDuration(5000L)
                .pick(this, new OnImagePickCompleteListener() {
                    @Override
                    public void onImagePickComplete(ArrayList<ImageItem> items) {
                        //图片选择回调，主线程
                        mainActivityView.notifyImageItemsCallBack(items);
                    }
                });
    }

    // silme
    // galleryi den getir diyim fotografı veya video yu acmıyor
    /** üzernide dur */
    @Override
    public void preview(final int pos) {
        final ArrayList<ImageItem> resultList = mainActivityView.getPicList();
        IPickerPresenter presenter = weChatPresenter;

        ArrayList<String> list = new ArrayList<>();
        for (ImageItem imageItem : resultList) {
            if (imageItem.getCropUrl() != null && imageItem.getCropUrl().length() > 0) {
                list.add(imageItem.getCropUrl());
            } else {
                list.add(imageItem.path);
            }
        }

        ImagePicker.preview(this, presenter, list, pos, new OnImagePickCompleteListener() {
            @Override
            public void onImagePickComplete(ArrayList<ImageItem> items) {
                //图片编辑回调，主线程
                resultList.clear();
                mainActivityView.notifyImageItemsCallBack(items);
            } });
    }
}