package com.ypx.imagepickerdemo.preview;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.ypx.imagepicker.bean.ImageItem;
import com.ypx.imagepicker.widget.cropimage.CropImageView;
import java.util.ArrayList;
import java.util.List;

// Description: 图片区 <p> Author: peixing.yang Date: 2019/1/28
public class ImagesViewPager extends RelativeLayout {
    private ViewPager viewPager;
    private CircleImageIndicator circleImageIndicator;
    private LinearLayout indicatorLayout;

    // silme
    public ImagesViewPager(Context context) {
        super(context);
        style1();
    }

    // silme
    public ImagesViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        style1();
    }

    // silme
    public ImagesViewPager(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        style1();
    }

    // 普通样式
    public void style1() {
        removeAllViews();
        viewPager = new ViewPager(getContext());
        addView(viewPager, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        indicatorLayout = new LinearLayout(getContext());
        indicatorLayout.setGravity(Gravity.CENTER);
        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(CENTER_HORIZONTAL);
        params.addRule(ALIGN_PARENT_BOTTOM);
        params.addRule(BELOW, viewPager.getId());
        indicatorLayout.setPadding(0, 8, 0, 8);
        indicatorLayout.setBackgroundColor(Color.TRANSPARENT);
        addView(indicatorLayout, params);

        circleImageIndicator = new CircleImageIndicator(getContext());
        circleImageIndicator.setBackgroundColor(Color.TRANSPARENT);
        circleImageIndicator.setNormalColor(Color.RED);
        circleImageIndicator.setPressColor(Color.GREEN);
        circleImageIndicator.setBlendColors(true);
        indicatorLayout.addView(circleImageIndicator, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        circleImageIndicator.bindViewPager(viewPager);
    }
}
