package com.ypx.imagepickerdemo;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.bumptech.glide.Glide;
import com.ypx.imagepicker.bean.ImageItem;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

// silme
public class MainActivityView {

    // silme
    public interface MainViewCallBack {
        void weChatPick(int count);

        void preview(int pos);
    }

    private MainViewCallBack mainViewCallBack;
    final int maxCount = 3;
    private ArrayList<ImageItem> picList = new ArrayList<>();
    private GridLayout mGridLayout;

    private WeakReference<Activity> activityWeakReference;

    // silme
    public static MainActivityView create(Activity activity, MainViewCallBack mainViewCallBack) {
        return new MainActivityView(activity, mainViewCallBack);
    }

    // silme
    private MainActivityView(Activity activity, MainViewCallBack mainViewCallBack) {
        this.mainViewCallBack = mainViewCallBack;
        activityWeakReference = new WeakReference<>(activity);
        activity.setContentView(R.layout.activity_camera_portrate);
        initView(activity);
        picList = new ArrayList<>();
        refreshGridLayout();
    }

    // silme
    private void initView(Activity activity) {
        mGridLayout = activity.findViewById(R.id.gridLayout);
    }

    // silme
    private void refreshGridLayout() {
        mGridLayout.setVisibility(View.VISIBLE);
        mGridLayout.removeAllViews();
        int num = picList.size();
        final int picSize = (getScreenWidth() - 20) / 4;
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(picSize, picSize);
        if (num >= maxCount) {
            mGridLayout.setVisibility(View.VISIBLE);
            for (int i = 0; i < num; i++) {
                RelativeLayout view = (RelativeLayout) LayoutInflater.from(getActivity()).inflate(R.layout.a_layout_pic_select, null);
                view.setLayoutParams(params);
                view.setPadding(5, 5, 5, 5);
                setPicItemClick(view, i);
                mGridLayout.addView(view);
            }
        } else {
            mGridLayout.setVisibility(View.VISIBLE);
            ImageView imageView = new ImageView(getActivity());
            imageView.setLayoutParams(params);
            imageView.setImageDrawable(getActivity().getResources().getDrawable(R.mipmap.add_pic));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(5, 5, 5, 5);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startPick();
                }
            });
            for (int i = 0; i < num; i++) {
                RelativeLayout view = (RelativeLayout) LayoutInflater.from(getActivity()).inflate(R.layout.a_layout_pic_select, null);
                view.setLayoutParams(params);
                view.setPadding(5, 5, 5, 5);
                setPicItemClick(view, i);
                mGridLayout.addView(view);
            }
            mGridLayout.addView(imageView);
        }
    }

    // silme
    private void setPicItemClick(RelativeLayout layout, final int pos) {
        ImageView iv_pic = (ImageView) layout.getChildAt(0);
        ImageView iv_close = (ImageView) layout.getChildAt(1);
        displayImage(picList.get(pos), iv_pic);
        iv_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picList.remove(pos);
                refreshGridLayout();
            }
        });
        iv_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainViewCallBack.preview(pos);
            }
        });
    }

    // silme
    private void displayImage(ImageItem imageItem, ImageView imageView) {
        if (imageItem.getCropUrl() != null && imageItem.getCropUrl().length() > 0) {
            Glide.with(getActivity()).load(imageItem.getCropUrl()).into(imageView);
        } else {
            if (imageItem.getUri() != null) {
                Glide.with(getActivity()).load(imageItem.getUri()).into(imageView);
            } else {
                Glide.with(getActivity()).load(imageItem.path).into(imageView);
            }
        }
    }

    // silme
    private Activity getActivity() {
        return activityWeakReference.get();
    }

    // silme
    private int getScreenWidth() {
        WindowManager wm = (WindowManager) getActivity().getSystemService(Activity.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        assert wm != null;
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }

    // silme
    public void startPick() {
            mainViewCallBack.weChatPick(maxCount - picList.size());
    }

    // silme
    public ArrayList<ImageItem> getPicList() {
        return picList;
    }

    // silme
    public void notifyImageItemsCallBack(ArrayList<ImageItem> imageItems) {
        picList.addAll(imageItems);
        refreshGridLayout();
    }
}